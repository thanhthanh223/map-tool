create FUNCTION GET_MA_KHU_VUC(
    p_ma_tt IN VARCHAR2,
    p_ma_px IN VARCHAR2
) RETURN VARCHAR2 IS
    v_prefix VARCHAR2(50) /

